function []=run(Af) %%AF:amplitude of fluctuations in the feeding region
%% ==============================================================================
%%Time sewries code-By Taranjot Kaur
%%Last date modified-02-09-2024
%%Copyright Taranjot Kaur/ tchkaur@ucdavis.edu
%% ==============================================================================
if nargin <1
    Af=round(linspace(0,10,10),1);
end


clear all
clc
global ro e1 eps
eps=1; as=1;ms=5;%% warming scenario
%% Parameters.............
Aq=8000;Trq=297;qtr=0.005; %% monotonically decreasing

%attack rate
aopt=1;sa=6;To_a=300; %% hump shaped

%growth rate
ropt=1;sr=6;To_r=300; %% hump shaped

%mortality
mopt=0.1 ;Am=10000;Tref=297; %% monotonically increasing

%%  
%%------------------------------------
Kb = 8.617*10^(-5);
ro = 100;
Mc = 500;
e1 = 0.8;
Ag = 0.15;
Ng = 0;
Tl = 27 ;
Tu = 30;
Lt = 1;
Q  = exp(0.72)*Mc^(0.36);
Nf = 25;
p  = 100;


%% TIME PARAMETERS %%
% time steps %
N = 3650000;
tstart = 0;  tend = 36500;
h = (tend-tstart)/N;      %% The step size
t(1) = tstart;
t_total = tstart:h:tend;
 
fin_time=N-500000;

%% Choose the scenario :)..................................................................
sim= menu ( ' Which evironmental scenario user wants to use :)', ...
'static-no fluctuations !!' , 'temporal fluctuations :)', 'spatiotemporal fluctuations :D');
%% ..................................................................................

Res=[];Cons=[];TC=[];JJ=[];mm=[];RR=[];KK=[];LLt=[];time=[];TF=[];TG=[];int=[];
Res_wo=[];max_ene=[];mcr=[];roK=[];


for ii=1:length(Af)

 % fid(file_no) = fopen(sprintf('/home/taran/Desktop/WORK_THEMAL REFUGIA/PARAMETERISED_DATA/PARAMETERISED_DATA/DATA_refugia_thresh/Af_sim%d.dat',file_no),'w' );

    ii
n=1 ;                    % for storing
w(:,1)= [30 20];        % initial conditions
w1(:,1)=[30 0];

switch sim
case 1 %%STATIC
    t(1)=tstart;
    for i = 1:N  %% generating time series  using RK4 method

        Tf1=Nf+1*Af(ii);   % temperature of feeding arena
        Tc=Tf1(1);           % initial temperature for consumer same as of the feeding arena
        
        Tr=Tf1;              % resource temperature
        
        r=ropt*exp(-((Tr+273)-To_r)^2/(2*sr^2));   %% growth rate
        q=qtr*exp(Aq*((1/Trq)-(1/(Tr+273))));
        K=q;
        Tc = Tc+h*((1/Q)*(Tf1-Tc));  %% consumer body temperature
        J=Lt*aopt*exp(-((Tc+273)-To_a)^2/(2*sa^2));  %% attack rate
        m=mopt*exp(Am*((1/Tref)-(1/(Tc+273))));
        
        
        %%RK4-method %%here "f" is the function file to call the consumer-resource system
        k1 = h*f_2d(t(i),r,K,J,m,w(:,i));
        k2 = h*f_2d(t(i)+h/2,r,K,J,m, w(:,i)+0.5*k1);
        k3 = h*f_2d(t(i)+h/2,r,K,J,m,w(:,i)+0.5*k2);
        k4 = h*f_2d(t(i)+h,r,K,J,m, w(:,i)+k3);

        w(:,i+1) = w(:,i) + (k1 + 2*k2 + 2*k3 + k4)/6;

        t(i+1) = tstart + i*h;
        
        %storing data beyond time=9000;
        if i>fin_time
            time(n,ii)=t(i);
            JJ(n,ii)=J;        %%storing attack rate 
            MM(n,ii)=m;        %%storing metabolic rate 
            RR(n,ii)=r;
            KK(n,ii)=K;  
            LLt(n,ii)=Lt;
            TC(n,ii)=Tc; 
            TF(n,ii)=Tf1; %%stofiring consumer body temperature 
            Res(n,ii)=w(1,i);  %%storing resource biomass denisty
            Cons(n,ii)=w(2,i); %%storing consumer biomass denisty
            int(n,ii)=(e1*J-m)/(m*ro*K);
            max_ene(n,ii)=e1.*J/m;
            roK(n,ii)=ro*K;
            mcr(n,ii)=m./r;
            n=n+1;
                   
        end

    end

    
case 2 %%TEMPORAL

  t(1)=tstart;
    Tf1(1)=(Nf+ms*t(1)/tend)+(1*Af(ii)+1*as*t(1)/tend)*sin(t_total(1)/p);

    Tc=Tf1(1);
    for jj=1:N-1

        Tf1 = (Nf+ms*t_total(jj+1)/tend)+(1*Af(ii)+1*as*t_total(jj+1)/tend)*sin(t_total(jj+1)/p);
       
        Tr = Tf1;
        r=ropt*exp(-((Tr+273)-To_r)^2/(2*sr^2));  %% growth rate
        q=qtr*exp(Aq*((1/Trq)-(1/(Tr+273))));
        K=q;
        

        Tc = Tc+h*((1/Q)*(Tf1-Tc));

        J=Lt*aopt*exp(-((Tc+273)-To_a)^2/(2*sa^2));   %% attack rate
        m=mopt*exp(Am*((1/Tref)-(1/(Tc+273))));

        k1 = h*f_2d(t(jj),r,K,J,m, w(:,jj));
        k2 = h*f_2d(t(jj)+h/2,r,K,J,m, w(:,jj)+0.5*k1);
        k3 = h*f_2d(t(jj)+h/2,r,K,J,m, w(:,jj)+0.5*k2);
        k4 = h*f_2d(t(jj)+h,r,K,J,m, w(:,jj)+k3);

        w(:,jj+1) = w(:,jj) + (k1 + 2*k2 + 2*k3 + k4)/6;
       
        t(jj+1) = tstart + jj*h;

        if jj>fin_time
            time(n,ii)=t(jj);
            JJ(n,ii)=J;
            MM(n,ii)=m;
            RR(n,ii)=r;
            KK(n,ii)=K;  
            LLt(n,ii)=Lt;
            TC(n,ii)=Tc;
            TF(n,ii)=Tf1; 
            Res(n,ii)=w(1,jj);        
            Cons(n,ii)=w(2,jj);
            int(n,ii)=(e1*J-m)/(m*ro*K);
            max_ene(n,ii)=e1.*J/m;
            roK(n,ii)=ro*K;
            mcr(n,ii)=m./r;
            n=n+1;
           end
    end

    
case 3 %%SPATIO-TEMPORAL
    t(1)=tstart;
    Tf1(1)=(Nf+ms*t(1)/tend)+(1*Af(ii)+1*as*t(1)/tend)*sin(t_total(1)/p);

    Tc(1) = Tf1(1);
    Lt(1) = 1;
    
    for jj = 1:N-1

        Tf1 = (Nf+ms*t_total(jj+1)/tend)+(1*Af(ii)+1*as*t_total(jj+1)/tend)*sin(t_total(jj+1)/p);
        Tr = Tf1;
        r=ropt*exp(-((Tr+273)-To_r)^2/(2*sr^2));  %% growth rate
        q=qtr*exp(Aq*((1/Trq)-(1/(Tr+273))));
        K=q;

       %% CASE: Crossed upper threshold. Therefore, moves to Refugia
       if Tc(jj)>=Tu
           
           Lt(jj)=0;
           
           
       %% CASE: does not cross the threshold, remains in feeding area
       elseif Tc(jj)<=Tl
           
           Lt(jj)=1;
           
           
       %% CASE: Temperature within the upper and lower threshold then 
       else % if (Tl<Tc(jj)) && (Tc(jj)<Tu)
           
           if jj>1 % if the time iteration is more than 1
               % checking location at previous time and updating next location. 
               if Lt(jj-1)==0  % if earlier in refugia then remains in refugia
                   Lt(jj)=0;

               elseif Lt(jj-1)==1 % if earlier in feeding area then remains there
                   Lt(jj)=1;
                   
               end
   
           else %% if first time step, keep in feeding area
               Lt(jj)=1;
           end
       end
 

        %%Refugia thermal condition
        %Tg1 = Nf+0.5*Af(ii)*Ag-0.5*Af(ii)*Ag*sin(t_total(jj+1)/p)+Ng;
        Tg1 = Nf+(Af(ii)*Ag)*sin(t_total(jj+1)/p)+Ng;
        
        %%Consumer body temperature depending upon location
        Tc(jj+1) = Tc(jj)+h*((1/Q)*(Lt(jj)*Tf1+(1-Lt(jj))*Tg1-Tc(jj)));
        J=Lt(jj)*aopt*exp(-((Tc(jj)+273)-To_a)^2/(2*sa^2));   %% attack rate
        %m=mopt*exp(Am*((1/Tref)-(1/(Tc(jj)+273))))*(1+exp(AL*((1/TL)-(1/(Tc(jj)+273)))));  %% mortality/ metabolic rate
        m=mopt*exp(Am*((1/Tref)-(1/(Tc(jj)+273))));
        
       
           
        k1 = h*f_2d(t(jj),r,K,J,m, w(:,jj));
        k2 = h*f_2d(t(jj)+h/2,r,K,J,m, w(:,jj)+0.5*k1);
        k3 = h*f_2d(t(jj)+h/2,r,K,J,m, w(:,jj)+0.5*k2);
        k4 = h*f_2d(t(jj)+h,r,K,J,m, w(:,jj)+k3);

        w(:,jj+1) = w(:,jj) + (k1 + 2*k2 + 2*k3 + k4)/6;
  
        t(jj+1) = tstart + jj*h;


        if jj>fin_time 
           
            TG(n,ii)=Tg1;
            TF(n,ii)=Tf1;
            time(n,ii)=t(jj);
            JJ(n,ii)=J;
            MM(n,ii)=m;
            RR(n,ii)=r;
            KK(n,ii)=K;  
            LLt(n,ii)=Lt(jj);
            TC(n,ii)=Tc(jj);
            Res(n,ii)=w(1,jj);          
            Cons(n,ii)=w(2,jj);
            int(n,ii)=(e1*J-m)/(m*ro*K);
            max_ene(n,ii)=e1.*J/m;
            roK(n,ii)=ro*K;
            mcr(n,ii)=m./r;
            n=n+1;
           
        end
        
    end

end

end

save Cons.dat Cons -ascii
save time.dat time -ascii 
save Res.dat Res -ascii
save LLt.dat LLt -ascii
save R.dat RR -ascii
save M.dat MM -ascii
save JJ.dat JJ -ascii
save K.dat KK -ascii


Mat=monodromy();
%%%%%%%%%%%%%%%%%%%%%______________________________________%%%%%%%%%%%%%%%%%%%%%%
% figure(1)
% 
% mc=mean(mcr);RhK=mean(roK);
% int_str=mean(int);rho=mean(max_ene);
% subplot(4,4,9)
% plot(Af,mc);
% hold on;
% subplot(4,4,10)
% plot(Af,RhK);
% hold on;
% subplot(4,4,11)
% plot(Af,int_str);
% hold on;
% subplot(4,4,12)
% plot(Af,rho);
% hold on;
end

