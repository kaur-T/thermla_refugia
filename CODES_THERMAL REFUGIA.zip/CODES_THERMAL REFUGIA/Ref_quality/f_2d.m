function dy = f_2d(t,r,K,J,m, y)
global ro e1
dy = [y(1)*r*(1-y(1)*K)-J*y(2)*(y(1)/(y(1)+ro));
      y(2)*(J*(e1*y(1)/(y(1)+ro))-m)];

%%