%% ==============================================================================
%% 3-D plot depicting consumer biomass for varying range of amplitudes (Af and Ag)-Taranjot Kaur
% Last date modified-02-26-2024
% Copyright-Taranjot Kaur (2017maz0004@iitrpr.ac.in/ tchkaur@ucdavis.edu)
%% ==============================================================================

clear all
clc

global ro e1

%% Parameters.............
Aq=8000;Trq=297;qtr=0.005;

%attack rate
aopt=1;sa=6;To_a=300;

%growth rate
ropt=1;sr=6;To_r=300;

%mortality
mopt=0.1;Am=10000;Tref=297;

%%
%%------------------------------------
Kb = 8.617*10^(-5);ro = 100;Mc = 50;e1 = 0.8;e2 = 0.8;Ag = 0.15;Ng = 0;
Tl = 27;Tu = 30;Lt = 1;Q  = exp(0.72)*Mc^(0.36);Nf = 25;p=100;

Af = linspace(0,20,10); %% Amplitude of fluctuations:range
Ag = linspace(0,1,10); %% Amplitude of fluctuations in refugia:range



%% TIME PARAMETERS %%
% time steps %
N = 3650000;
tstart = 0;  tend = 36500;
h = (tend-tstart)/N;      %% The step size
t(1) = tstart;
t_total = tstart:h:tend;



Res=[];Cons=[];TC=[];JJ=[];mm=[];RR=[];KK=[];LLt=[];

for ii=1:length(Af)
    ii
    for ii1=1:length(Ag)
  
n=1 ;                    % for storing
w(:,1)= [10 100];        % initial conditions


    Tf1(1)=Nf+0.5*Af(ii)-0.5*Af(ii)*sin(t_total(1)/p);

    Tc(1) = Tf1(1);
    Lt(1) = 1;
    
    for jj = 1:N-1

        Tf1 = Nf+0.5*Af(ii)-0.5*Af(ii)*sin(t_total(jj+1)/p);
        Tr = Tf1;
        r=ropt*exp(-((Tr+273)-To_r)^2/(2*sr^2));  %% growth rate
        q=qtr*exp(Aq*((1/Trq)-(1/(Tr+273))));
        K=q;

       %% CASE: Crossed upper threshold. Therefore, moves to Refugia
       if Tc(jj)>=Tu
           
           Lt(jj)=0;
           
           
       %% CASE: does not cross the threshold, remains in feeding area
       elseif Tc(jj)<=Tl
           
           Lt(jj)=1;
           
           
       %% CASE: Temperature within the upper and lower threshold then 
       else % if (Tl<Tc(jj)) && (Tc(jj)<Tu)
           
           if jj>1 % if the time iteration is more than 1
               % checking location at previous time and updating next location. 
               if Lt(jj-1)==0  % if earlier in refugia then remains in refugia
                   Lt(jj)=0;

               elseif Lt(jj-1)==1 % if earlier in feeding area then remains there
                   Lt(jj)=1;
                   
               end
   
           else %% if first time step, keep in feeding area
               Lt(jj)=1;
           end
       end
     


        %%Refugia thermal condition
        Tg1= Nf+0.5*Af(ii)*Ag(ii1)-0.5*Af(ii)*Ag(ii1)*sin(t_total(jj+1)/p)+Ng;
        %%Consumer body temperature depending upon location
        Tc(jj+1) = Tc(jj)+h*((1/Q)*(Lt(jj)*Tf1+(1-Lt(jj))*Tg1-Tc(jj)));
        J=Lt(jj)*aopt*exp(-((Tc(jj)+273)-To_a)^2/(2*sa^2));   %% attack rate
        m=mopt*exp(Am*((1/Tref)-(1/(Tc(jj)+273))));
        
       %%RK-4
           
        k1 = h*f_2d(t(jj),r,K,J,m, w(:,jj));
        k2 = h*f_2d(t(jj)+h/2,r,K,J,m, w(:,jj)+0.5*k1);
        k3 = h*f_2d(t(jj)+h/2,r,K,J,m, w(:,jj)+0.5*k2);
        k4 = h*f_2d(t(jj)+h,r,K,J,m, w(:,jj)+k3);

        w(:,jj+1) = w(:,jj) + (k1 + 2*k2 + 2*k3 + k4)/6;
        t(jj+1) = tstart + jj*h;

        err=abs(w(2,jj+1)-w(2,jj));
       
        
        if jj>1800000 
            
            Res(n)=w(1,jj);
            Cons(n)=w(2,jj);
            n=n+1;
        end
    end

    Cons_biomass(ii1,ii)=mean(Cons);
    Res_biomass(ii1,ii)=mean(Res);
    end
end



