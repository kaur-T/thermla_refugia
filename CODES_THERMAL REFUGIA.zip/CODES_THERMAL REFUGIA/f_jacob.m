function dy = f_jacob(t,a11,a12,a21,a22,y)
global ro e1

dy = [a11*y(1)+a12*y(3);a11*y(2)+a12*y(4);a21*y(1)+a22*y(3);a21*y(2)+a22*y(4)];

%%