
%% ==============================================================================
%% Consumer biomass for varying period of fluctuations-By Taranjot Kaur
%% Last date modified-02-09-2024
%% ==============================================================================

clear all
clc

global ro e1

%% Parameters.............
Aq=8000;Trq=297;qtr=0.005;

%attack rate
aopt=1;sa=6;To_a=300;

%growth rate
ropt=1;sr=6;To_r=300;

%mortality
mopt=0.1;Am=10000;Tref=297;

%%
%%------------------------------------
Kb = 8.617*10^(-5);ro = 100;Mc = 50;e1 = 0.8;e2 = 0.8;Ag = 0.15;Ng = 0;
Tl = 27;Tu = 30;Lt = 1;Q  = exp(0.72)*Mc^(0.36);Nf = 25;

Af = 12.5; %% Amplitude of fluctuations:range
p=linspace(1,100,20);

%% TIME PARAMETERS %%
% time steps %
N = 3650000;
tstart = 0;  tend = 36500;
h = (tend-tstart)/N;      %% The step size
t(1) = tstart;
t_total = tstart:h:tend;


%% Choose the scenario :)..................................................................
sim= menu ( ' Which evironmental scenario user wants to use :)', ...
'static-no fluctuations !!' , 'temporal fluctuations :)', 'spatiotemporal fluctuations :D');
%% ........................................................................................

Res=[];Cons=[];TC=[];JJ=[];mm=[];RR=[];KK=[];LLt=[];

for ii=1:length(p)
   
    ii
n=1 ;                    % for storing
w(:,1)= [10 100];        % initial conditions


switch sim
case 1 %%STATIC
    Tf1=Nf+0.5*Af;   % temperature of feeding arena
    Tc=Tf1(1);           % initial temperature for consumer same as of the feeding arena
    
    Tr=Tf1;              % resource temperature 
      
    r=ropt*exp(-((Tr+273)-To_r)^2/(2*sr^2));   %% growth rate
    q=qtr*exp(Aq*((1/Trq)-(1/(Tr+273))));
    K=q;
   



    for i = 1:N  %% generating time series  using RK4 method

        Tc = Tc+h*((1/Q)*(Tf1-Tc));  %% consumer body temperature
        J=Lt*aopt*exp(-((Tc+273)-To_a)^2/(2*sa^2));  %% attack rate
        m=mopt*exp(Am*((1/Tref)-(1/(Tc+273))));
        
        
        %%RK4-method %%here "f" is the function file to call the consumer-resource system
        k1 = h*f_2d(t(i),r,K,J,m, w(:,i));
        k2 = h*f_2d(t(i)+h/2,r,K,J,m, w(:,i)+0.5*k1);
        k3 = h*f_2d(t(i)+h/2,r,K,J,m, w(:,i)+0.5*k2);
        k4 = h*f_2d(t(i)+h,r,K,J,m, w(:,i)+k3);

        w(:,i+1) = w(:,i) + (k1 + 2*k2 + 2*k3 + k4)/6;
        t(i+1) = tstart + i*h;

        %storing data beyond time=9000;
        if i>1500000
            JJ(n,ii)=J;        %%storing attack rate 
            MM(n,ii)=m;        %%storing metabolic rate 
            RR(n,ii)=r;
            KK(n,ii)=K;  
            LLt(n,ii)=Lt;
            TC(n,ii)=Tc;       %%storing consumer body temperature 
            Res(n,ii)=w(1,i);  %%storing resource biomass denisty
            Cons(n,ii)=w(2,i); %%storing consumer biomass denisty
            n=n+1;
        end


    end

    
case 2 %%TEMPORAL

    Tf1(1)=Nf+0.5*Af-0.5*Af*sin(t_total(1)/p(ii));

    Tc=Tf1(1);

    for jj=1:N-1

        Tf1 = Nf+0.5*Af-0.5*Af*sin(t_total(jj+1)/p(ii));
        Tr = Tf1;
        r=ropt*exp(-((Tr+273)-To_r)^2/(2*sr^2));  %% growth rate
        q=qtr*exp(Aq*((1/Trq)-(1/(Tr+273))));
        K=q;
        

        Tc = Tc+h*((1/Q)*(Tf1-Tc));

        J=Lt*aopt*exp(-((Tc+273)-To_a)^2/(2*sa^2));   %% attack rate
        %m=mopt*exp(Am*((1/Tref)-(1/(Tc+273))))*(1+exp(AL*((1/TL)-(1/(Tc+273)))));  %% mortality/ metabolic rate
        m=mopt*exp(Am*((1/Tref)-(1/(Tc+273))));

        k1 = h*f_2d(t(jj),r,K,J,m, w(:,jj));
        k2 = h*f_2d(t(jj)+h/2,r,K,J,m, w(:,jj)+0.5*k1);
        k3 = h*f_2d(t(jj)+h/2,r,K,J,m, w(:,jj)+0.5*k2);
        k4 = h*f_2d(t(jj)+h,r,K,J,m, w(:,jj)+k3);

        w(:,jj+1) = w(:,jj) + (k1 + 2*k2 + 2*k3 + k4)/6;
        t(jj+1) = tstart + jj*h;

        if jj>1500000
            JJ(n,ii)=J;
            MM(n,ii)=m;
            RR(n,ii)=r;
            KK(n,ii)=K;  
            LLt(n,ii)=Lt;
            TC(n,ii)=Tc;
            Res(n,ii)=w(1,jj);
            Cons(n,ii)=w(2,jj);
            n=n+1;
        end
    end

    
case 3 %%SPATIO-TEMPORAL

    Tf1(1)=Nf+0.5*Af-0.5*Af*sin(t_total(1)/p(ii));

    Tc(1) = Tf1(1);
    Lt(1) = 1;
    
    for jj = 1:N-1

        Tf1 = Nf+0.5*Af-0.5*Af*sin(t_total(jj+1)/p(ii));
        Tr = Tf1;
        r=ropt*exp(-((Tr+273)-To_r)^2/(2*sr^2));  %% growth rate
        q=qtr*exp(Aq*((1/Trq)-(1/(Tr+273))));
        K=q;

       %% CASE: Crossed upper threshold. Therefore, moves to Refugia
       if Tc(jj)>=Tu
           
           Lt(jj)=0;
           
           
       %% CASE: does not cross the threshold, remains in feeding area
       elseif Tc(jj)<=Tl
           
           Lt(jj)=1;
           
           
       %% CASE: Temperature within the upper and lower threshold then 
       else % if (Tl<Tc(jj)) && (Tc(jj)<Tu)
           
           if jj>1 % if the time iteration is more than 1
               % checking location at previous time and updating next location. 
               if Lt(jj-1)==0  % if earlier in refugia then remains in refugia
                   Lt(jj)=0;

               elseif Lt(jj-1)==1 % if earlier in feeding area then remains there
                   Lt(jj)=1;
                   
               end
   
           else %% if first time step, keep in feeding area
               Lt(jj)=1;
           end
       end
       
       
%      %% adaptive step size
%       if (jj>=2)
%           if (Lt(jj)~=Lt(jj-1))
%               h=0.001;
%           else
%               h=0.01;
%           end
%       end
             



        %%Refugia thermal condition
        Tg1 = Nf+0.5*Af*Ag-0.5*Af*Ag*sin(t_total(jj+1)/p(ii))+Ng;
        %%Consumer body temperature depending upon location
        Tc(jj+1) = Tc(jj)+h*((1/Q)*(Lt(jj)*Tf1+(1-Lt(jj))*Tg1-Tc(jj)));
        J=Lt(jj)*aopt*exp(-((Tc(jj)+273)-To_a)^2/(2*sa^2));   %% attack rate
        %m=mopt*exp(Am*((1/Tref)-(1/(Tc(jj)+273))))*(1+exp(AL*((1/TL)-(1/(Tc(jj)+273)))));  %% mortality/ metabolic rate
        m=mopt*exp(Am*((1/Tref)-(1/(Tc(jj)+273))));
        
       
           
        k1 = h*f_2d(t(jj),r,K,J,m, w(:,jj));
        k2 = h*f_2d(t(jj)+h/2,r,K,J,m, w(:,jj)+0.5*k1);
        k3 = h*f_2d(t(jj)+h/2,r,K,J,m, w(:,jj)+0.5*k2);
        k4 = h*f_2d(t(jj)+h,r,K,J,m, w(:,jj)+k3);

        w(:,jj+1) = w(:,jj) + (k1 + 2*k2 + 2*k3 + k4)/6;
        t(jj+1) = tstart + jj*h;

        err=abs(w(2,jj+1)-w(2,jj));
        
       %% adaptive step size
       
        
        if jj>1500000 
            HH(n,ii)=h;
            JJ(n,ii)=J;
            MM(n,ii)=m;
            RR(n,ii)=r;
            KK(n,ii)=K;  
            LLt(n,ii)=Lt(jj);
            TC(n,ii)=Tc(jj);
            Res(n,ii)=w(1,jj);
            Cons(n,ii)=w(2,jj);
            n=n+1;
        end
    end

end


end



