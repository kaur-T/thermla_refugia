%%=================================================================================
function Mat=monodromy()
%% Calculating the floquet multipliers using the monodromy matrix- Taranjot Kaur
% Last date modified-02-27-2024
% Copyright-Taranjot Kaur (2017maz0004@iitrpr.ac.in/ tchkaur@ucdavis.edu)
%%=================================================================================
clear all
clc
global ro e1 


format long
Mc = 500;
Q  = exp(0.72)*Mc^(0.36);

ro=100;

%%load data
load time.dat; 
load Cons.dat; load Res.dat; load LLt.dat
load R.dat; load M.dat; load J.dat; load K.dat

t=time; 
Cons=Cons;  Res=Res;  r=R;  
J=J; m=Mat;  K=K;  LLt=LLt;

%%calculating the period of fluctuation in spceies density
mph=max(Cons);
[a,b]=findpeaks(Cons,'MinPeakHeight', mph-0.03);
period=round(mean(diff(t(b))./0.01));    %%in continuous time

t1=1:period;
count=0;
t=t(1:period);
T=t;


Cons=Cons(1:(period)); %% data with complete cycle
LLt=LLt(1:(period));
Res=Res(1:(period));
r=r(1:(period));
J=J(1:(period));
K=K(1:(period));
m=m(1:(period));


for j=1:length(LLt)-1

    if LLt(j)~=LLt(j+1)
       
    count=count+1; % no of switching
    jump_index(count)=LLt(j)-LLt(j+1); %% switching from which sub-system (f_-f+)
    jumpp_time(count)=T(j+1); %switching instant
    jumpp_time1(count)=t1(j+1);
    end
    
end


e1=0.8;
h=0.01;

if count==0
  
  jump_time1=T(end)-T(1) ;
  jump_time2=[T(1) T(end)];
    
else
jump_time1=[jumpp_time(1)-T(1) diff(jumpp_time) T(end)-jumpp_time(end)]; %% period corr to a sub-system


jump_time2=[T(1) jumpp_time T(end)]; %% all the times...

end

ct=0;
w(:,1)=[1 0 0 1];
for jj=1:length(jump_time2)-1 %% time loop

tstart=jump_time2(jj);

for i= jump_time2(jj):jump_time2(jj+1)  % start time to end time
   
T(1)=tstart;
ct=ct+1;
%% Monodromy matrix
a11=r(ct)*(1-2*Res(ct)*K(ct))-(J(ct)*ro*Cons(ct))/((Res(ct)+ro)^2);

a12=-J(ct)*Res(ct)/(Res(ct)+ro);

a21=e1*J(ct)*ro*Cons(ct)/((Res(ct)+ro)^2);

a22=(e1*J(ct)*Res(ct)/(Res(ct)+ro))-m(ct);


k1 = h*f_jacob(t(ct),a11,a12,a21,a22, w(:,ct));
k2 = h*f_jacob(t(ct)+h/2,a11,a12,a21,a22, w(:,ct)+0.5*k1);
k3 = h*f_jacob(t(ct)+h/2,a11,a12,a21,a22, w(:,ct)+0.5*k2);
k4 = h*f_jacob(t(ct)+h,a11,a12,a21,a22, w(:,ct)+k3);

w(:,ct+1) = w(:,ct) + (k1 + 2*k2 + 2*k3 + k4)/6;
tt(ct+1) = tstart + ct*h;

end
AA{jj}=w(:,end);
end



for kk=1:length(AA)
    AA{kk}=reshape(AA{kk},2,2);
    AA{kk}=AA{kk}';
end
    



for ii=1:count   %% no. of jumps
   
    jump_time=jumpp_time1(ii);  %%with switching instant  
  
    
  if jump_index(ii)==-1
      
      
      Sal{ii}=eye(2)+[J(jump_time)*Res(jump_time)*Cons(jump_time)/((Res(jump_time)+ro)*(r(jump_time)*Res(jump_time)*(1-Res(jump_time)*K(jump_time))-((J(jump_time)*Res(jump_time)*Cons(jump_time))/(Res(jump_time)+ro)))) 0; -e1*J(jump_time)*Res(jump_time)*Cons(jump_time)/((Res(jump_time)+ro)*(r(jump_time)*Res(jump_time)*(1-Res(jump_time)*K(jump_time))-((J(jump_time)*Res(jump_time)*Cons(jump_time))/(Res(jump_time)+ro)))) 0];
  elseif jump_index(ii)==1
      
      Sal{ii}=eye(2)+[-J(jump_time)*Res(jump_time)*Cons(jump_time)/((Res(jump_time)+ro)*(r(jump_time)*Res(jump_time)*(1-Res(jump_time)*K(jump_time)))) 0;e1*J(jump_time)*Res(jump_time)*Cons(jump_time)/((Res(jump_time)+ro)*(r(jump_time)*Res(jump_time)*(1-Res(jump_time)*K(jump_time)))) 0]; 
        
   end

  
end


if count==0
Mat=AA{1};
else
Mat=AA{count};
end 


if count~=0
for jjk=(count):-1:1
    jjk
Mat=Mat*Sal{jjk}*AA{jjk};
end
end
end
